<div>
    <div class="container">
        <div class="p-2">
            <div class="col-md-12">
                <div class="card shadow">

                    <div class="card-header">
                        <div class="card-title">
                            <h2>{{ $page->title }}</h2>
                        </div>
                    </div>
                    <div class="card-body">
                        {!! $page->description !!}
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
