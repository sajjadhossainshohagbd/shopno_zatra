<div>
    <div class="container">
        <div class="p-2">
            <div class="col-md-12">
                <div class="card shadow">

                    <div class="card-header">
                        <div class="card-title">
                            <h2>About Us</h2>
                        </div>
                    </div>
                    <div class="card-body">
                        {!! settings('about_us') !!}
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
