<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HajjOrder extends Model
{
    use HasFactory;

    public function hajj()
    {
        return $this->hasOne(Hajj::class,'id','hajj_id');
    }

    public function user()
    {
        return $this->hasOne(User::class,'id','user_id');
    }

}
